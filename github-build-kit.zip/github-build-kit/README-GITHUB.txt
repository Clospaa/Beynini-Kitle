TELEFONDAN APK DERLEME - GITHUB ACTIONS

1) GitHub'da New repository ile yeni bir repository oluştur (Private seçebilirsin).
2) Bu paketin içindeki iki öğeyi repository'nin köküne yükle:
   - my-app-source-fixed.zip
   - .github/workflows/android-apk.yml
   GitHub web'de Add file > Upload files yolunu kullan. Klasör yapısı .github/workflows/android-apk.yml olarak kalmalı.
3) Commit changes ile yüklemeyi tamamla.
4) Repository > Actions sekmesine gir. "Build Android APK" iş akışını aç.
5) Çalışma bitince yeşil tikli çalışmaya gir, Artifacts bölümünden my-app-debug-apk dosyasını indir.
6) İnen artifact ZIP'ini telefonda aç; içindeki app-debug.apk dosyasını kur.

NOTLAR:
- GitHub hesabının şifresini, erişim tokenını veya özel anahtarını kimseyle paylaşma.
- Bu işlem debug APK üretir; Play Store için imzalı release APK/AAB değildir.
- Derleme başarılı olsa bile gerçek telefonda erişilebilirlik izni ve uygulama engelleme davranışı ayrıca test edilmelidir.
